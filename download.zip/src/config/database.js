const mongoose = require('mongoose');
require('dotenv').config(); // Carrega as variáveis do arquivo .env

const connectToDatabase = async () => {
  try {
    const dbUri = process.env.MONGODB_URI; // Obtém a URL do MongoDB do arquivo .env
    if (!dbUri) {
      throw new Error('MONGODB_URI is not defined in .env file');
    }
    await mongoose.connect(dbUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Connected to MongoDB');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
  }
};

module.exports = connectToDatabase;
