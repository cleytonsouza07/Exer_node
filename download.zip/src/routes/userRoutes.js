const express = require('express');
const { register, login, listUsers, updateUser, deleteUser } = require('../controllers/userController');
const authenticate = require('../middlewares/authenticate');

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/users', authenticate, listUsers);
router.put('/user', authenticate, updateUser);
router.delete('/user', authenticate, deleteUser);

module.exports = router;
