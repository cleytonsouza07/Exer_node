const express = require('express');
const connectToDatabase = require('./config/database');
const userRoutes = require('./routes/userRoutes');
const dotenv = require('dotenv');

require('dotenv').config(); // Carrega variáveis de ambiente
const connectToDatabase = require('./config/database');

// Conecte-se ao MongoDB
connectToDatabase();

dotenv.config();
const app = express();

app.use(express.json());
app.use('/api', userRoutes);

connectToDatabase()
  .then(() => {
    app.listen(process.env.PORT || 3000, () => {
      console.log(`Server running on port ${process.env.PORT || 3000}`);
    });
  })
  .catch(error => {
    console.error('Failed to connect to database', error);
    process.exit(1);
  });
